from flask_app import app
from flask import render_template, redirect, request, session
from flask_app.models.user import USER
from flask_bcrypt import Bcrypt        
bcrypt = Bcrypt(app)     # we are creating an object called bcrypt, 
                         # which is made by invoking the function Bcrypt with our app as an argument




@app.route('/')
def index():
    return  render_template("index.html")

@app.route('/users/new', methods=['post'])
def create_user():
    pw_hash = bcrypt.generate_password_hash(request.form['password'])
    if USER.validate_user(request.form) == False:
        return redirect('/')
    
    data = {
        'first_name':request.form['first_name'],
        'last_name':request.form['last_name'],
        'email':request.form['email'],
         "password" : pw_hash 
        #  hashage password
    }
    return_from_db = USER.create_user(data)
    session['user_id'] = return_from_db
    print("-"*20,return_from_db,"-"*20)
    return redirect('/')
    # return hedha bech nhezzouh l session (return_from_db)
    
    